<?php

return [
    'email' => 'contact@matthiashacksteiner.net',
    'language' => 'de',
    'name' => '',
    'role' => 'admin'
];